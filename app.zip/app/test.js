global.funcaoTeste1 = function(){
  console.log("funcionou")
}

global.funcaoTeste2 = function(){
  console.log("funcionou 1")
}

global.funcaoTeste3 = function(){
  console.log("funcionou 2")
}

let a = 3
global['funcaoTeste' + a]()