# Programa de Gerenciador de Metas (Requisitos)
- [x] Criar metas
- [x]  Listar metas
  - [x] Metas concluídas
  - [x]  Metas abertas
- [x]  Marcar/desmarcar metas como concluída
- [x]  Remover metas
- [x] Sistema de carregar e salvar metas
- [x] Persistir dados
- [x] Sistema de nuvem (GitHub)